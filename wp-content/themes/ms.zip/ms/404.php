<!-- Archivo de cabecera global de Wordpress -->
<?php get_header(); ?>
<!-- notfound -->
<?php get_template_part('partials/404/notfound'); ?>
<!-- notfound -->
<!-- recommends -->
<?php get_template_part('partials/404/recommends'); ?>
<!-- recommends -->
<!-- Archivo de pié global de Wordpress -->
<?php get_footer(); ?>
