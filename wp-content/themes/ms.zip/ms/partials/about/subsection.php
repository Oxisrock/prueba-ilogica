<section class="subsection pb-4 pt-4">
    <div class="container">
        <div class="row">
            <div class="col-12 col-md-6">
                <h2 class=""><?= the_field('title_second'); ?></h2>
                <div class="content"><?= the_field('content_second'); ?></div>
            </div>
            <div class="col-12 col-md-6">
                <div class="bg-orange">
                    <img src="<?= the_field('image_second')?>" class="img-fluid original-image" alt="">
                    <div class="back-orange">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>