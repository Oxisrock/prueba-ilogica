<section class="background-page-content pb-4 pt-4">
    <div class="container">
        <div class="row">
            <div class="col-8 col-md-8">
                <div class="content"><?php the_content(); ?></div>
            </div>
        </div>
    </div>
</section>