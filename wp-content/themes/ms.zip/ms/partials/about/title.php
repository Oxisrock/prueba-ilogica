<section class="background-page">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="title-page"><?php the_title(); ?></h1>
            </div>
        </div>
    </div>
</section>