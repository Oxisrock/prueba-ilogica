<section class="background-activity">
    <div class="">
        <div class="grid-container">
            <div class="">
                <a href="/actividades"><i class="fas fa-arrow-left"></i> volver actividades</a>
            </div>
            <div class="">
                <h1 class="title-page"><?php the_title(); ?></h1>
            </div>
        </div>
    </div>
</section>