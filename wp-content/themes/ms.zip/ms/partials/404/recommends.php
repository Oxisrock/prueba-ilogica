<section class="recommeds">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="whatfound pb-4 text-center">
                    <h2 class="pb-4">¿Qué estás buscando?</h2>
                    <div class="btns">
                        <a href="/about" class="btn btn-red">Nosotros</a>
                        <a href="/actividades" class="btn btn-red">Actividades</a>
                        <a href="/about#contact" class="btn btn-red">Contacto</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>