<section class="404">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="notfound text-center">
                    <img src="<?= get_template_directory_uri(); ?>/assets/img/404.png" class="img-fluid" alt="">
                    <h1>Página no encontrada</h1>
                </div>
            </div>
        </div>
    </div>
</section>