<!-- Archivo de cabecera global de Wordpress -->
<?php get_header(); ?>
<!-- slider -->
<?php get_template_part('partials/front-page/slider'); ?>
<!-- slider -->
<!-- previo -->
<?php get_template_part('partials/front-page/previo'); ?>
<!-- previo -->
<!-- tree -->
<?php get_template_part('partials/front-page/tree'); ?>
<!-- tree -->
<!-- cuarta -->
<?php get_template_part('partials/front-page/cuarta'); ?>
<!-- cuarta -->
<!-- inta -->
<?php get_template_part('partials/front-page/inta'); ?>
<!-- inta -->
<!-- Archivo de pié global de Wordpress -->
<?php get_footer(); ?>
